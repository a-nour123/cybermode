<?php
bolt_decrypt( __FILE__ , 'hERkSN'); return 0;
##!!!##GBUYFXlseHB+e2xucCtMe3tnVHl/cH1xbG5wfkYYFRgVdHl/cH1xbG5wK154flR5f3B9cWxucBgVhhgVKysrK3uAbXd0bitxgHluf3R6eSt+cHlvXnh+My+AfnB9VG83L3hwfn5scnA0RhgViBgV
<?php
bolt_decrypt( __FILE__ , '5j0xLe'); return 0;
##!!!##BQIFAgUCZlllXWtoWVtdGDloaFRBZmxdal5ZW11rVDlcZWFmMwUCBQJhZmxdal5ZW10YTF1rbEFmbF1qXllbXQUCcwUCGBgYGGhtWmRhWxhebWZbbGFnZhhsXWtsSl1oZ2thbGdqcUxdW2BhZl1pXSAhMwUCdQUC